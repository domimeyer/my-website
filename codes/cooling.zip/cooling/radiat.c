#include "pluto.h"


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


//  #define frac_Z   1.e-3   /*   = N(Z) / N(H), fractional number density of metals (Z)  with respect to hydrogen (H) */ 
    #define frac_He  0.082   /*   = N(Z) / N(H), fractional number density of helium (He) with respect to hydrogen (H) */ 
//  #define A_Z      30.0    /*   mean atomic weight of heavy elements  */
//  #define A_He     4.004   /*   atomic weight of Helium  */
//  #define A_H      1.008   /*   atomic weight of Hydrogen  */

    #define corrHe   2.0*(1.0 + frac_He)

    #define Fit_m    1.02606078334
    #define Fit_p    0.127081464381

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


/* Declare heating rate function if needed (one can also use the )  */
real HeatingRateNeutral (real T);
real HeatingRateIonised (real T);
real TempOverMu  (real T);
real MeanMolecularWeightNeutral (real T);


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


void Radiat (real *v, real *rhs)
/* Cooling module for MS/RSG transitions */
{
  int    klo, khi, kmid;
  real   mu, T=0.0, Tmid, dT,  dToverMu,   g_time_rsg;
  real   scrh,  scrh_cool,  scrh_heat, x;
  static int ntabms, ntabrsg, ntabtovermu;
  static real *L_tab_MS_cool ,  *L_tab_MS_heat      , *T_tab_MS,   E_cost;
  static real *L_tab_RSG_cool,  *L_tab_RSG_heat     , *T_tab_RSG,  *M_tab_RSG_mu,  *T_tab_RSG_ToverMu, *X_tab_RSG; 

  real T_over_mu;
  real a = 0.0 ;
  real b = 0.0 ;

  FILE *f_ionised, *f_neutral, *f_tovermu;


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


/* -------------------------------------------
        Read parameter for cooling curve
   ------------------------------------------- */


  g_time_rsg = g_inputParam[TIME_RSG];


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


/* -------------------------------------------
        Read tabulated cooling functions
   ------------------------------------------- */

/*  For the fully ionised media (the MS curve) */

  if (T_tab_MS == NULL){
    print1 (" > Reading MS table from disk...\n");
    //f_ionised = fopen("curve_cooling_ionised.dat","r");
    f_ionised = fopen("curve_MB.dat","r");	
    if (f_ionised == NULL){
      print1 ("! MS table does not exists\n");
      QUIT_PLUTO(1);
    }
    T_tab_MS      = ARRAY_1D(20000, double);
    L_tab_MS_cool = ARRAY_1D(20000, double);
//    L_tab_MS_heat = ARRAY_1D(20000, double);

    ntabms = 0;
    while (fscanf(f_ionised, "%lf   %lf\n", T_tab_MS + ntabms, 
                                           L_tab_MS_cool  + ntabms )!=EOF) {
      ntabms++;
    }
    E_cost    = g_unitLength/g_unitDensity/pow(g_unitVelocity, 3.0);
  }

/*  For the cooling and heating of neutral media (the RSG curve) */

  if (T_tab_RSG == NULL){
    print1 (" > Reading RSG table from disk...\n");
    f_neutral = fopen("curve_dissipation_neutral.dat","r");
    if (f_neutral == NULL){
      print1 ("! RSG table does not exists\n");
      QUIT_PLUTO(1);
    }
    T_tab_RSG         = ARRAY_1D(20000, double);
    L_tab_RSG_cool    = ARRAY_1D(20000, double);
    L_tab_RSG_heat    = ARRAY_1D(20000, double);
    M_tab_RSG_mu      = ARRAY_1D(20000, double);
    T_tab_RSG_ToverMu = ARRAY_1D(20000, double);
    X_tab_RSG         = ARRAY_1D(20000, double);

    ntabrsg = 0;
    while (fscanf(f_neutral, "%lf    %lf    %lf    %lf    %lf     %lf\n", 
						T_tab_RSG         + ntabrsg, 
                                                L_tab_RSG_cool    + ntabrsg,
					        L_tab_RSG_heat    + ntabrsg,
						M_tab_RSG_mu      + ntabrsg,			
						T_tab_RSG_ToverMu + ntabrsg,  
 						X_tab_RSG         + ntabrsg	)!=EOF) {
      ntabrsg++;
    }
    E_cost    = g_unitLength/g_unitDensity/pow(g_unitVelocity, 3.0);
  }




//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


/* ----------------------------------------------
        Table lookup by binary search  
   ---------------------------------------------- */


/*  Decide which table to use as a function of the temperature  */
/*  This is for the MS (fully ionised medium )*/
  if ( g_time <  g_time_rsg ){  

/* ---------------------------------------------
            Get temperature 
   --------------------------------------------- */

  if (v[PRS] <= 0.0) v[PRS] = g_smallPressure;

  /*  ----- Get T, here it is very simple because we know mu -----  */

  mu  = MeanMolecularWeight(v);
  T   = v[PRS]/v[RHO]*KELVIN*mu;

  /*  ----- We have T ! ----- */


  if (T != T){
    printf (" ! Nan found in radiat \n");
    printf (" ! rho = %12.6e, pr = %12.6e\n",v[RHO], v[PRS]);
    QUIT_PLUTO(1);
  }

  if (T < 100.0 ) { 
    // No cooling if T if below table's Tmin 
    rhs[PRS] = 0.0;
    return;
  }

  klo = 0;
  khi = ntabms - 1;

 // /*  Use the MS cooling curve */
 // if (T > T_tab_MS[khi] || T < T_tab_MS[klo]){ 
 //   // If T out of range (too big), then choose the highest one
 //   T = 9.5907e+08;
 // }

  while (klo != (khi - 1)){
    kmid = (klo + khi)/2;
    Tmid = T_tab_MS[kmid];
    if (T <= Tmid){
      khi = kmid;
    }else if (T > Tmid){
      klo = kmid;
    }
  }

  dT        = T_tab_MS[khi] - T_tab_MS[klo];
  scrh_cool = L_tab_MS_cool[klo]*(T_tab_MS[khi] - T)/dT + L_tab_MS_cool[khi]*(T - T_tab_MS[klo])/dT;
//  scrh_heat = L_tab_MS_heat[klo]*(T_tab_MS[khi] - T)/dT + L_tab_MS_heat[khi]*(T - T_tab_MS[klo])/dT;
//  rhs[PRS]  = (g_gamma - 1.0)*(  HeatingRateIonised(T)*v[RHO]/mu  - scrh_cool*v[RHO]*v[RHO]/(mu*mu)  );

  rhs[PRS]  = (g_gamma - 1.0)*( 0.0 - scrh_cool*v[RHO]*v[RHO]/(mu*mu*corrHe*corrHe)  );

  rhs[PRS] *= E_cost*g_unitDensity*g_unitDensity/(CONST_mp*CONST_mp);


 }


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


  else{  


  /*  ----- Get T, here it is not so simple, but we are smart enougth -----  */


/* This is for the red super giant medium */          
  if (v[PRS] < 0.0) { v[PRS] = g_smallPressure; }


  /*  This takes into acccount the ionisation of the medium  */
  T_over_mu   = (v[PRS]/v[RHO])*((1.0e+5)*(1.0e+5)*CONST_amu/CONST_kB);   



  if (T_over_mu != T_over_mu){
    printf (" ! Nan found in radiat \n");
    printf (" ! rho = %12.6e, pr = %12.6e\n",v[RHO], v[PRS]);
    QUIT_PLUTO(1);
  } 


  if (T_over_mu < g_minCoolingTemp/1.4) { 
    // No cooling if T if below table's Tmin 
    rhs[PRS] = 0.0;
    return;
  }


  klo = 0;
  khi = ntabrsg - 1;


  if (T_over_mu > T_tab_RSG_ToverMu[khi] || T_over_mu < T_tab_RSG_ToverMu[klo]){
    // If T out of range (too big), then choose the highest one
    T_over_mu =9.5907e+08;
  }


  if (T > T_tab_RSG[khi] || T < T_tab_RSG[klo]){
    // If T out of range (too big), then choose the highest one
    T = 9.5907e+08;
  }


  while (klo != (khi - 1)){
    kmid = (klo + khi)/2;
    Tmid = T_tab_RSG_ToverMu[kmid];
    if (T_over_mu <= Tmid){
      khi = kmid;
    }else if (T_over_mu > Tmid){
      klo = kmid;
    }
  }

  // Integrant element
  dToverMu        = T_tab_RSG_ToverMu[khi] - T_tab_RSG_ToverMu[klo];


  // Get the right temperature
  T         = T_tab_RSG[klo]*( T_tab_RSG_ToverMu[khi] - T_over_mu )/dToverMu + T_tab_RSG[khi]*( T_over_mu - T_tab_RSG_ToverMu[klo] )/dToverMu;


  // Get mu
  mu        = M_tab_RSG_mu[klo]*( T_tab_RSG_ToverMu[khi] - T_over_mu )/dToverMu + M_tab_RSG_mu[khi]*( T_over_mu - T_tab_RSG_ToverMu[klo] )/dToverMu;


  // Get x (only for the test)
  x         = X_tab_RSG[klo]*( T_tab_RSG_ToverMu[khi] - T_over_mu )/dToverMu + X_tab_RSG[khi]*( T_over_mu - T_tab_RSG_ToverMu[klo] )/dToverMu;


  // Get coolants and heatants
  scrh_cool = L_tab_RSG_cool[klo]*(T_tab_RSG[khi] - T_over_mu)/dToverMu + L_tab_RSG_cool[khi]*(T_over_mu - T_tab_RSG[klo])/dToverMu;
  scrh_heat = L_tab_RSG_heat[klo]*(T_tab_RSG[khi] - T_over_mu)/dToverMu + L_tab_RSG_heat[khi]*(T_over_mu - T_tab_RSG[klo])/dToverMu;
//  rhs[PRS]  = (g_gamma - 1.0)*(  HeatingRateNeutral(T)*v[RHO]/mu  - scrh_cool*v[RHO]*v[RHO]/(mu*mu)  );
  rhs[PRS]  = (g_gamma - 1.0)*(  scrh_heat*v[RHO]/(mu*corrHe)  - scrh_cool*v[RHO]*v[RHO]/(mu*mu*corrHe*corrHe)  );
  rhs[PRS]  *= E_cost*g_unitDensity*g_unitDensity/(CONST_mp*CONST_mp);

      }
  
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


}
#undef T_MIN


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


/* Return the T for neutral medium knowing T/mu */
real TempOverMu (real T_over_mu)
{
  real a , b;

  a   =  1.3399; 
  b   =  0.9746;

  return  pow( T_over_mu - a , b );
}


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


double MeanMolecularWeight (real *V)
{
  // Return mean mass per particle
  return 0.61;
}


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


/* Return mean mass per particle for neutral media */
real MeanMolecularWeightNeutral (real T)
{
  real a, m, Xhe, x;

  m   = 1.02606078334; 
  a   = 0.97460;
  Xhe = 0.0786528;

  if ( T < 11700.0 ){  
                   x  = (2.3e-3)*sqrt(T/100.0)/1.1582;
		   return 1.4/( ( 1.0 + Xhe )*( 1.0 + x ) ) ; 
                   }
  else if ( T <= 1.0e+5 && T >= 11700.0  ){  
                   return T/(pow(T,m)+a);  
                   }
  else {  
       return 0.647507  ;  
       }

}


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


/* Return the "heating" rate of for ionsed media */
real HeatingRateIonised (real T)
{
  real a, b, c, d, eV, alpha;

  a     = 1.4712e-10;
  b     = -0.663985;
  c     = 4.03848e-4;
  d     = 0.694907;
  eV    = 1.602e-12;  
  alpha = 0.0;


  if ( T <= 9.5907e+08 ){  									
     alpha = (a*pow(T,b))/(1.0+c*pow(T,d)); 
     return 5.0*eV*alpha; 
  }
  else {
     return 1.0e-28;	
  }

}


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


/* Return the "heating" rate of for neutral media */
real HeatingRateNeutral (real T)
{
  real factor, exposant;

  factor   = 1.1287; 
  exposant = 0.1825;

  return (1.1e-25)/(1.0+factor*pow(T,exposant));
}


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


